(() => {
  if (window.__balloonLoaded) return;
  window.__balloonLoaded = true;

  const SITES = [
    { name: 'LeetCode', host: /(^|\.)leetcode\.(com|cn)$/, problem: /^\/problems\/[^/]+/ },
    { name: 'Codeforces', host: /(^|\.)codeforces\.com$/, problem: /^\/(problemset\/problem\/\d+\/\w+|(contest|gym)\/\d+\/problem\/\w+)/ },
    { name: 'CodeChef', host: /(^|\.)codechef\.com$/, problem: /^\/(?:[^/]+\/)?problems\/[^/]+/ },
    { name: 'GFG', host: /(^|\.)geeksforgeeks\.org$/, problem: /^\/problems\/[^/]+/ },
    { name: 'HackerRank', host: /(^|\.)hackerrank\.com$/, problem: /\/challenges\/[^/]+/ },
  ];

  const site = SITES.find((s) => s.host.test(location.hostname)) || null;
  const isProblemPage = () => Boolean(site && site.problem.test(location.pathname));

  const text = (el) => (el ? (el.innerText || el.textContent || '').trim() : '');

  function findDifficultyLabel() {
    const re = /^(easy|medium|hard|basic|school)$/i;
    for (const el of document.querySelectorAll('div, span, p, a')) {
      if (el.children.length === 0 && re.test(el.textContent.trim())) return el.textContent.trim();
    }
    return '';
  }

  function scrape() {
    const out = { siteTitle: '', h1: '', difficultyText: '', tags: [] };
    try {
      out.h1 = text(document.querySelector('h1'));

      if (site && site.name === 'Codeforces') {
        const head = text(document.querySelector('.problem-statement .header .title'));
        const m = head.match(/^([A-Za-z0-9]+)\.\s*(.+)$/);
        const contest = (location.pathname.match(/\/(\d+)\//) || [])[1] || '';
        if (m) out.siteTitle = `${m[2]} (${contest}${m[1]})`;
        const boxes = [...document.querySelectorAll('.tag-box')].map((el) => el.textContent.trim());
        const rating = boxes.find((t) => t.startsWith('*'));
        if (rating) out.difficultyText = rating;
        out.tags = boxes.filter((t) => t && !t.startsWith('*'));
      } else if (site && site.name === 'LeetCode') {
        out.tags = [...new Set([...document.querySelectorAll('a[href*="/tag/"]')].map((a) => a.textContent.trim()).filter(Boolean))];
        out.difficultyText = findDifficultyLabel();
      } else {
        out.difficultyText = findDifficultyLabel();
      }
    } catch {}
    return out;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message && message.action === 'getPageInfo') {
      sendResponse({ isProblemPage: isProblemPage(), siteName: site ? site.name : null, scraped: scrape() });
    }
    return false;
  });

  if (!site) return;

  let showButton = true;
  let host = null;
  let lastHref = location.href;

  chrome.storage.local.get('settings').then((data) => {
    if (data.settings && data.settings.showButton === false) showButton = false;
    sync();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings) {
      showButton = !changes.settings.newValue || changes.settings.newValue.showButton !== false;
      sync();
    }
  });

  const STYLE = `
    :host { all: initial; }
    .wrap { position: fixed; right: 18px; bottom: 18px; z-index: 2147483647; font: 13px/1.4 system-ui, "Segoe UI", sans-serif; }
    .fab { width: 42px; height: 42px; border-radius: 50%; border: 0; cursor: pointer; background: #3B5BDB; color: #fff;
           display: grid; place-items: center; box-shadow: 0 4px 14px rgba(20, 30, 70, .35); }
    .fab:hover { background: #2F4BC0; }
    .fab:focus-visible, .opt:focus-visible { outline: 3px solid #A8B8FF; outline-offset: 2px; }
    .panel { position: absolute; right: 0; bottom: 52px; width: 230px; padding: 12px; border-radius: 12px; background: #fff; color: #18213A;
             box-shadow: 0 8px 28px rgba(20, 30, 70, .3); border: 1px solid #DCE1EC; }
    .panel[hidden] { display: none; }
    .head { font-weight: 650; margin-bottom: 8px; }
    .row { display: flex; gap: 6px; }
    .opt { flex: 1; padding: 7px 4px; border-radius: 8px; border: 1px solid #DCE1EC; background: #F5F7FB; color: inherit; cursor: pointer; font: inherit; }
    .opt:hover { border-color: #3B5BDB; }
    .opt[aria-pressed="true"] { background: #3B5BDB; border-color: #3B5BDB; color: #fff; }
    .msg { margin-top: 8px; min-height: 18px; color: #5B667D; }
    .msg.err { color: #C42B47; }
  `;

  function mount() {
    host = document.createElement('div');
    host.id = 'balloon-root';

    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `
      <style>${STYLE}</style>
      <div class="wrap">
        <div class="panel" hidden role="dialog" aria-label="Save to Balloon">
          <div class="head">Save to Balloon</div>
          <div class="row">
            <button class="opt" data-status="To-Do" aria-pressed="false">To-Do</button>
            <button class="opt" data-status="Attempted" aria-pressed="false">Attempted</button>
            <button class="opt" data-status="Solved" aria-pressed="false">Solved</button>
          </div>
          <div class="msg" role="status"></div>
        </div>
        <button class="fab" aria-label="Save this problem to Balloon" title="Save to Balloon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M12 2C8 2 5.5 5.2 5.5 9c0 3.9 2.9 7 6.5 7s6.5-3.1 6.5-7C18.5 5.2 16 2 12 2z"/>
            <path d="M10.8 16.2h2.4l.9 1.7H9.9z"/>
            <path d="M12 18c-1.2 1.7 1.2 2.7 0 4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
          </svg>
        </button>
      </div>`;
    const panel = root.querySelector('.panel');
    const msg = root.querySelector('.msg');
    const buttons = [...root.querySelectorAll('.opt')];

    const mark = (status) => buttons.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.status === status)));
    const say = (t, isError = false) => { msg.textContent = t; msg.classList.toggle('err', isError); };

    const send = (payload) =>
      new Promise((resolve) => {
        try {
          chrome.runtime.sendMessage(payload, (res) => resolve(chrome.runtime.lastError ? null : res));
        } catch {
          resolve(null);
        }
      });

    root.querySelector('.fab').addEventListener('click', async () => {
      panel.hidden = !panel.hidden;
      if (panel.hidden) return;
      say('');
      mark(null);
      const res = await send({ action: 'lookup', url: location.href });
      if (res && res.ok && res.status) { mark(res.status); say('Already saved. Pick a status to update it.'); }
    });

    buttons.forEach((btn) =>
      btn.addEventListener('click', async () => {
        say('Saving…');
        const res = await send({
          action: 'quickSave',
          status: btn.dataset.status,
          page: { url: location.href, tabTitle: document.title, scraped: scrape() },
        });
        if (!res) return say('Reload this tab to reconnect the extension.', true);
        if (!res.ok) return say(res.error || 'Could not save.', true);
        mark(res.status);
        const verb = res.result === 'added' ? 'Saved' : 'Updated';
        say(res.review ? `${verb} as ${res.status}. Revise ${res.review}.` : `${verb} as ${res.status}.`);
      })
    );

    document.documentElement.appendChild(host);
  }

  function unmount() {
    if (host) host.remove();
    host = null;
  }

  function sync() {
    const wanted = showButton && isProblemPage();
    if (wanted && !host) mount();
    else if (!wanted && host) unmount();
    else if (wanted && host && location.href !== lastHref) {
      unmount();
      mount();
    }
    lastHref = location.href;
  }

  let timer = null;
  new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(sync, 300);
  }).observe(document.documentElement, { childList: true, subtree: true });

  sync();
})();
