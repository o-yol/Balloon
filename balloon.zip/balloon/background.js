import { getProblems, upsertByUrl, findByUrl } from './lib/storage.js';
import { dueList } from './lib/insights.js';
import { buildDraft } from './lib/platforms.js';
import { toKey, relativeLabel } from './lib/dates.js';

const ALARM = 'refresh-badge';

async function refreshBadge() {
  const due = dueList(await getProblems(), toKey()).length;
  await chrome.action.setBadgeText({ text: due > 0 ? String(due) : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#3B5BDB' });
}

function ensureAlarm() {
  chrome.alarms.get(ALARM, (alarm) => {
    if (!alarm) chrome.alarms.create(ALARM, { periodInMinutes: 60 });
  });
}

ensureAlarm();

chrome.runtime.onInstalled.addListener(() => {
  ensureAlarm();
  refreshBadge();
});
chrome.runtime.onStartup.addListener(() => {
  ensureAlarm();
  refreshBadge();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) refreshBadge();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.problems) refreshBadge();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || !message.action) return false;

  if (message.action === 'lookup') {
    getProblems()
      .then((list) => {
        const found = findByUrl(list, message.url);
        sendResponse({ ok: true, status: found ? found.status : null });
      })
      .catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (message.action === 'quickSave') {
    const draft = buildDraft(message.page);
    if (!draft.url) {
      sendResponse({ ok: false, error: 'This page cannot be saved.' });
      return false;
    }
    upsertByUrl({ ...draft, status: message.status })
      .then(({ result, problem }) =>
        sendResponse({
          ok: true,
          result,
          status: problem.status,
          review: problem.nextReview ? relativeLabel(problem.nextReview) : null,
        })
      )
      .catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  return false;
});
