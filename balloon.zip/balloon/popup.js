import {
  getProblems, getSettings, saveSettings, addProblem, updateProblem, deleteProblem,
  recordReview, clearAll, exportData, importData, findByUrl, normalizeTags,
} from './lib/storage.js';
import { PLATFORMS, buildDraft, detectPlatform, normalizeUrl } from './lib/platforms.js';
import { toKey, relativeLabel, daysBetween, timeAgo, shortDate } from './lib/dates.js';
import { overview, streaks, heatmap, heatLevel, topTags, dueList, upcomingList, filterProblems } from './lib/insights.js';
import { MAX_STAGE } from './lib/review.js';

const $ = (id) => document.getElementById(id);
const SVG_NS = 'http://www.w3.org/2000/svg';
const DEFAULT_FILTERS = { q: '', tag: '', platform: '', difficulty: '', status: '', sort: 'newest' };
const STATUS_ICON = { 'To-Do': 'todo', Attempted: 'attempted', Solved: 'solved' };

const state = {
  problems: [],
  settings: { theme: 'auto', showButton: true },
  tab: 'log',
  page: { draft: buildDraft(), existing: null, onProblemPage: false },
  editingId: null,
  formTags: [],
  filters: { ...DEFAULT_FILTERS },
  confirmDeleteId: null,
  confirmClear: false,
  flashId: null,
  balloonsShown: false,
};

function h(tag, props = {}, ...kids) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (value == null || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'dataset') Object.assign(node.dataset, value);
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? '' : value);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    node.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return node;
}

function setChildren(parent, ...kids) {
  parent.replaceChildren(...kids.flat().filter((k) => k != null && k !== false));
}

function icon(name, className = '', style = '') {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('class', `icon ${className}`.trim());
  svg.setAttribute('aria-hidden', 'true');
  if (style) svg.setAttribute('style', style);
  const use = document.createElementNS(SVG_NS, 'use');
  use.setAttribute('href', `#i-${name}`);
  svg.append(use);
  return svg;
}

function iconButton(name, label, dataset, extraClass = '') {
  return h('button', { class: `icon-btn ${extraClass}`.trim(), type: 'button', 'aria-label': label, title: label, dataset }, icon(name));
}

let toastTimer;
function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}

const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;

function resolveTheme() {
  if (state.settings.theme === 'light' || state.settings.theme === 'dark') return state.settings.theme;
  return matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function applyTheme() {
  const theme = resolveTheme();
  document.documentElement.dataset.theme = theme;
  $('theme-icon').setAttribute('href', theme === 'dark' ? '#i-sun' : '#i-moon');
}

async function reload() {
  state.problems = await getProblems();
  state.page.existing = findByUrl(state.problems, state.page.draft.url);
  updateDueBadge();
}

function updateDueBadge() {
  const due = dueList(state.problems, toKey()).length;
  const badge = $('due-badge');
  badge.hidden = due === 0;
  badge.textContent = due > 99 ? '99+' : String(due);
}

async function detectPage() {
  let tab = null;
  try {
    [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  } catch {}
  if (!tab || !tab.url) return { draft: buildDraft(), existing: null, onProblemPage: false };

  let info = null;
  try {
    info = await chrome.tabs.sendMessage(tab.id, { action: 'getPageInfo' });
  } catch {}

  const draft = buildDraft({ url: tab.url, tabTitle: tab.title || '', scraped: info && info.scraped });
  const existing = findByUrl(state.problems, tab.url);
  return { draft, existing, onProblemPage: Boolean(info && info.isProblemPage) || Boolean(existing) };
}

function switchTab(name) {
  state.tab = name;
  document.querySelectorAll('.tab').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === name)));
  document.querySelectorAll('.view').forEach((v) => { v.hidden = v.id !== `view-${name}`; });
  renderTab(name);
  document.querySelector('.views').scrollTop = 0;
}

function renderTab(name) {
  if (name === 'revise') renderRevise();
  else if (name === 'library') renderLibrary();
  else if (name === 'stats') renderStats();
}

const radio = (name) => {
  const el = document.querySelector(`input[name="${name}"]:checked`);
  return el ? el.value : '';
};
function setRadio(name, value) {
  const el = document.querySelector(`input[name="${name}"][value="${CSS.escape(value)}"]`);
  if (el) el.checked = true;
}

function setBanner(text, cancelable = false) {
  $('log-banner').hidden = !text;
  $('log-banner-text').textContent = text || '';
  $('cancel-edit').hidden = !cancelable;
}

function fillForm(p) {
  $('f-title').value = p.title || '';
  $('f-platform').value = PLATFORMS.includes(p.platform) ? p.platform : 'Other';
  setRadio('difficulty', p.difficulty || '');
  setRadio('status', p.status || 'Solved');
  state.formTags = normalizeTags(p.tags || []);
  $('f-time').value = p.timeSpent || '';
  $('f-url').value = p.url || '';
  $('f-notes').value = p.notes || '';
  $('f-tag-input').value = '';
  $('err-title').hidden = true;
  $('err-url').hidden = true;
  renderChips();
  updateStatusHint();
  $('save-btn').textContent = state.editingId ? 'Save changes' : 'Save problem';
}

function resetFormToPage() {
  const { draft, existing } = state.page;
  if (existing) {
    state.editingId = existing.id;
    fillForm(existing);
    setBanner('This page is already in your library. Saving updates that entry.');
  } else {
    state.editingId = null;
    fillForm({ ...draft, status: 'Solved' });
    setBanner('');
  }
}

function startEdit(id) {
  const problem = state.problems.find((p) => p.id === id);
  if (!problem) return;
  state.editingId = id;
  fillForm(problem);
  setBanner(`Editing “${problem.title}”`, true);
  switchTab('log');
}

function updateStatusHint() {
  const editing = state.editingId && state.problems.find((p) => p.id === state.editingId);
  let message;
  if (radio('status') !== 'Solved') {
    message = 'Joins your revision queue once it is marked Solved.';
  } else if (editing && editing.status === 'Solved') {
    message = editing.nextReview ? `Next review ${relativeLabel(editing.nextReview)}.` : 'Mastered. No more reviews scheduled.';
  } else {
    message = 'Joins your revision queue. First review tomorrow.';
  }
  $('status-hint').textContent = message;
}

function renderChips() {
  $('tag-chips').replaceChildren(
    ...state.formTags.map((tag) =>
      h('span', { class: 'chip' }, tag,
        h('button', { type: 'button', 'aria-label': `Remove ${tag}`, dataset: { action: 'tag-remove', tag } }, icon('x')))
    )
  );
  const all = new Set(state.problems.flatMap((p) => p.tags));
  $('tag-suggestions').replaceChildren(
    ...[...all].filter((t) => !state.formTags.includes(t)).sort().map((t) => h('option', { value: t }))
  );
}

function commitPendingTag() {
  const input = $('f-tag-input');
  for (const tag of normalizeTags(input.value)) {
    if (!state.formTags.includes(tag) && state.formTags.length < 12) state.formTags.push(tag);
  }
  input.value = '';
  renderChips();
}

async function onSubmit(event) {
  event.preventDefault();
  commitPendingTag();

  const title = $('f-title').value.trim();
  $('err-title').hidden = Boolean(title);
  if (!title) return $('f-title').focus();

  const rawUrl = $('f-url').value.trim();
  const url = rawUrl ? normalizeUrl(rawUrl) : '';
  const urlProblem = rawUrl && !url ? 'The link must start with http:// or https://' : null;
  const clash = url && findByUrl(state.problems, url);
  const targetId = state.editingId || (clash && clash.id) || null;
  const clashesWithOther = clash && state.editingId && clash.id !== state.editingId;

  const urlError = urlProblem || (clashesWithOther ? 'Another saved problem already uses this link.' : null);
  $('err-url').hidden = !urlError;
  $('err-url').textContent = urlError || '';
  if (urlError) return $('f-url').focus();

  const data = {
    title,
    platform: $('f-platform').value,
    difficulty: radio('difficulty'),
    status: radio('status'),
    tags: state.formTags,
    timeSpent: $('f-time').value,
    notes: $('f-notes').value,
    url,
  };

  const button = $('save-btn');
  button.disabled = true;
  try {
    const saved = targetId ? await updateProblem(targetId, data) : await addProblem(data);
    await reload();
    resetFormToPage();
    state.filters = { ...DEFAULT_FILTERS };
    syncFilterControls();
    state.flashId = saved.id;

    let message = targetId ? 'Changes saved.' : 'Problem saved.';
    if (saved.status === 'Solved' && saved.nextReview && !targetId) message += ` First review ${relativeLabel(saved.nextReview)}.`;
    toast(message);
    switchTab('library');
  } catch (err) {
    console.error(err);
    toast('Could not save. Please try again.');
  } finally {
    button.disabled = false;
  }
}

function syncFilterControls() {
  $('q').value = state.filters.q;
  $('flt-platform').value = state.filters.platform;
  $('flt-difficulty').value = state.filters.difficulty;
  $('flt-status').value = state.filters.status;
  $('sort').value = state.filters.sort;
}

function diffLabel(p) {
  return p.difficulty ? h('span', { class: `diff diff-${p.difficulty.toLowerCase()}`, text: p.difficulty }) : null;
}

function titleEl(p) {
  return p.url
    ? h('a', { class: 'row-title', href: p.url, target: '_blank', rel: 'noreferrer', title: p.title, text: p.title })
    : h('span', { class: 'row-title', title: p.title, text: p.title });
}

function problemRow(p) {
  const confirming = state.confirmDeleteId === p.id;
  const actions = confirming
    ? h('div', { class: 'confirm' }, 'Delete?',
        h('button', { class: 'btn-sm danger', type: 'button', dataset: { action: 'confirm-delete', id: p.id }, text: 'Delete' }),
        h('button', { class: 'btn-sm', type: 'button', dataset: { action: 'cancel-delete' }, text: 'Keep' }))
    : h('div', { class: 'row-actions' },
        iconButton('edit', `Edit ${p.title}`, { action: 'edit', id: p.id }),
        iconButton('trash', `Delete ${p.title}`, { action: 'ask-delete', id: p.id }, 'danger'));

  return h('li', { id: `row-${p.id}` },
    h('div', { class: 'row' },
      h('span', { class: `state ${p.status === 'To-Do' ? 'is-todo' : ''}`, role: 'img', 'aria-label': p.status, title: p.status },
        icon(STATUS_ICON[p.status] || 'todo')),
      h('div', { class: 'row-main' },
        titleEl(p),
        h('div', { class: 'row-meta' },
          h('span', { text: p.platform }),
          diffLabel(p),
          p.timeSpent ? h('span', { text: `${p.timeSpent} min` }) : null,
          h('span', { text: timeAgo(p.addedAt) })),
        p.tags.length
          ? h('div', { class: 'row-tags' },
              p.tags.map((t) => h('button', { class: 'tag-link', type: 'button', dataset: { action: 'filter-tag', tag: t }, text: `#${t}` })))
          : null),
      actions));
}

function renderLibrary() {
  const f = state.filters;
  const list = filterProblems(state.problems, f);

  const counter = $('result-count');
  const countText = list.length === state.problems.length ? plural(list.length, 'problem') : `${list.length} of ${state.problems.length}`;
  setChildren(counter,
    countText,
    f.tag
      ? h('span', { class: 'chip' }, `#${f.tag}`,
          h('button', { type: 'button', 'aria-label': 'Remove topic filter', dataset: { action: 'clear-tag' } }, icon('x')))
      : null
  );

  const ul = $('problem-list');
  if (list.length === 0) {
    const filtered = state.problems.length > 0;
    ul.replaceChildren(
      h('li', { class: 'empty' },
        h('strong', { text: filtered ? 'No matches' : 'Your library is empty' }),
        filtered
          ? h('span', {}, 'Try a different search, or ', h('button', { class: 'link-btn', type: 'button', dataset: { action: 'clear-filters' }, text: 'clear the filters' }), '.')
          : 'Open a problem page and use the Log tab, or the balloon button on the page, to save your first one.')
    );
    return;
  }
  ul.replaceChildren(...list.map(problemRow));

  if (state.flashId) {
    const row = $(`row-${state.flashId}`);
    if (row) {
      row.scrollIntoView({ block: 'nearest' });
      row.classList.add('row-flash');
    }
    state.flashId = null;
  }
}

function stageDots(stage) {
  return h('span', { class: 'stage', role: 'img', 'aria-label': `${stage} of ${MAX_STAGE} reviews done` },
    Array.from({ length: MAX_STAGE }, (_, i) => h('i', { class: i < stage ? 'on' : '' })));
}

function dueText(p, today) {
  const late = daysBetween(p.nextReview, today);
  return late <= 0 ? 'Due today' : `${plural(late, 'day')} overdue`;
}

function reviewRow(p, today) {
  return h('div', { class: 'review-row' },
    h('div', { class: 'review-top' },
      h('div', { class: 'row-main' },
        titleEl(p),
        h('div', { class: 'row-meta' },
          h('span', { text: p.platform }),
          diffLabel(p),
          h('span', { text: `Review ${p.reviewStage + 1} of ${MAX_STAGE}` }),
          h('span', { text: dueText(p, today) }))),
      stageDots(p.reviewStage)),
    h('div', { class: 'review-actions' },
      h('button', { class: 'btn-sm solid', type: 'button', dataset: { action: 'review-yes', id: p.id }, text: 'Got it' }),
      h('button', { class: 'btn-sm', type: 'button', dataset: { action: 'review-no', id: p.id }, text: 'Struggled' })));
}

function renderRevise() {
  const today = toKey();
  const due = dueList(state.problems, today);
  const upcoming = upcomingList(state.problems, today, 5);
  const anySolved = state.problems.some((p) => p.status === 'Solved');

  let dueBody;
  if (due.length) {
    dueBody = h('ul', { class: 'rows' }, due.map((p) => h('li', {}, reviewRow(p, today))));
  } else if (!anySolved) {
    dueBody = h('div', { class: 'panel empty' }, h('strong', { text: 'Nothing to revise yet' }),
      'Problems you mark as Solved come back after 1, 3, 7, 14 and 30 days.');
  } else if (upcoming.length) {
    dueBody = h('div', { class: 'panel empty' }, h('strong', { text: 'You are all caught up' }),
      `Next review ${relativeLabel(upcoming[0].nextReview, today)}.`);
  } else {
    dueBody = h('div', { class: 'panel empty' }, h('strong', { text: 'Everything is mastered' }), 'No reviews are scheduled.');
  }

  setChildren($('revise-root'),
    h('div', { class: 'block' },
      h('h2', { class: 'section-title' }, 'Due today', h('span', { text: due.length ? `${due.length} to review` : '' })),
      dueBody),
    upcoming.length
      ? h('div', { class: 'block' },
          h('h2', { class: 'section-title', text: 'Coming up' }),
          h('ul', { class: 'rows' },
            upcoming.map((p) => h('li', { class: 'upcoming-row' }, titleEl(p), h('span', { class: 'when', text: relativeLabel(p.nextReview, today) })))))
      : null
  );
}

const DIFF_COLOR = { Easy: 'var(--easy)', Medium: 'var(--medium)', Hard: 'var(--hard)' };

function balloon(color, index, title) {
  const svg = icon('balloon', 'balloon', `--i:${index};color:${color}`);
  svg.append(Object.assign(document.createElementNS(SVG_NS, 'title'), { textContent: title }));
  return svg;
}

function barRow(label, percent, valueText, color) {
  return h('div', { class: 'bar-row' },
    h('span', { text: label }),
    h('span', { class: 'track' }, h('i', { class: 'fill', style: `--pct:${percent};--c:${color}` })),
    h('span', { class: 'val', text: valueText }));
}

function renderStats() {
  const today = toKey();
  const o = overview(state.problems);
  const { current, best } = streaks(state.problems, today);

  const solved = state.problems
    .filter((p) => p.status === 'Solved')
    .sort((a, b) => (b.solvedOn || '').localeCompare(a.solvedOn || ''));
  const shown = solved.slice(0, 40);
  const rise = !state.balloonsShown;
  state.balloonsShown = true;

  const shelf = h('section', { class: 'panel shelf' },
    h('div', { class: 'shelf-head' },
      h('h2', { text: o.solved ? `${o.solved} solved` : 'No balloons yet' }),
      h('span', { class: 'streak' }, current > 0 ? `${current}-day streak` : 'No streak yet',
        best > 0 ? h('span', { class: 'muted', text: `, best ${best}` }) : null)),
    o.solved
      ? h('div', { class: `balloons ${rise ? 'rise' : ''}`, role: 'img', 'aria-label': `${o.solved} solved problems` },
          shown.map((p, i) => balloon(DIFF_COLOR[p.difficulty] || 'var(--accent)', i, p.title)),
          solved.length > shown.length ? h('span', { class: 'balloon-more', text: `+${solved.length - shown.length}` }) : null)
      : h('p', { class: 'hint', text: 'Log a solved problem to launch your first one. Each balloon is one solved problem.' }),
    o.solved
      ? h('div', { class: 'legend' },
          ['Easy', 'Medium', 'Hard'].map((d) => h('span', {}, h('i', { style: `--c:${DIFF_COLOR[d]}` }), d)),
          h('span', {}, h('i', { style: '--c:var(--accent)' }), 'Unrated'))
      : null);

  const blocks = [];

  if (o.total) {
    blocks.push(h('section', { class: 'block' },
      h('h3', { text: 'Progress' }),
      h('div', { class: 'split', role: 'img', 'aria-label': `${o.solved} solved, ${o.attempted} attempted, ${o.todo} to do` },
        o.solved ? h('i', { class: 's-solved', style: `flex:${o.solved}` }) : null,
        o.attempted ? h('i', { class: 's-attempted', style: `flex:${o.attempted}` }) : null,
        o.todo ? h('i', { class: 's-todo', style: `flex:${o.todo}` }) : null),
      h('div', { class: 'split-legend' },
        h('span', {}, h('i', { style: 'background:var(--accent)' }), h('b', { text: o.solved }), 'solved'),
        h('span', {}, h('i', { style: 'background:var(--heat-2)' }), h('b', { text: o.attempted }), 'attempted'),
        h('span', {}, h('i', { style: 'background:var(--heat-1)' }), h('b', { text: o.todo }), 'to do'),
        o.avgTime ? h('span', { class: 'muted', text: `avg ${o.avgTime} min per solve` }) : null)));

    blocks.push(h('section', { class: 'block' },
      h('h3', { text: 'By difficulty' }),
      ['Easy', 'Medium', 'Hard'].map((d) => {
        const { total, solved: s } = o.byDifficulty[d];
        return barRow(d, total ? Math.round((s / total) * 100) : 0, `${s} of ${total}`, DIFF_COLOR[d]);
      })));

    const max = o.byPlatform[0][1];
    blocks.push(h('section', { class: 'block' },
      h('h3', { text: 'By platform' }),
      o.byPlatform.slice(0, 5).map(([name, count]) => barRow(name, Math.round((count / max) * 100), String(count), 'var(--accent)'))));

    const tags = topTags(state.problems, 8);
    if (tags.length) {
      blocks.push(h('section', { class: 'block' },
        h('h3', { text: 'Top topics' }),
        h('div', { class: 'pills' },
          tags.map(([tag, count]) => h('button', { class: 'pill', type: 'button', dataset: { action: 'filter-tag', tag } }, `#${tag}`, h('span', { text: count }))))));
    }

    const hm = heatmap(state.problems, today, 18);
    blocks.push(h('section', { class: 'block' },
      h('h3', { text: 'Solved per day, last 18 weeks' }),
      h('div', { class: 'heat', role: 'img', 'aria-label': 'Activity heatmap' },
        hm.cells.map((c) => h('i', c
          ? { class: `lv${heatLevel(c.count, hm.max)}`, title: `${shortDate(c.date)}: ${c.count} solved` }
          : { class: 'none' }))),
      h('div', { class: 'heat-legend' }, 'Less', h('i'), h('i', { class: 'lv1' }), h('i', { class: 'lv2' }), h('i', { class: 'lv3' }), h('i', { class: 'lv4' }), 'More')));
  }

  const inTab = document.documentElement.classList.contains('as-tab');
  blocks.push(h('section', { class: 'block' },
    h('h3', { text: 'Your data' }),
    h('div', { class: 'btn-row' },
      h('button', { class: 'btn-ghost', type: 'button', dataset: { action: 'export' } }, icon('download'), 'Export backup'),
      h('button', { class: 'btn-ghost', type: 'button', dataset: { action: 'import' } }, icon('upload'), 'Import backup'),
      inTab ? null : h('button', { class: 'btn-ghost', type: 'button', dataset: { action: 'open-tab' } }, icon('window'), 'Open in a tab'),
      state.problems.length
        ? h('button', {
            class: `btn-ghost ${state.confirmClear ? 'danger-armed' : 'danger'}`, type: 'button',
            dataset: { action: state.confirmClear ? 'clear-confirm' : 'clear-ask' },
            text: state.confirmClear ? 'Really delete everything?' : 'Delete all',
          })
        : null),
    h('label', { class: 'check' },
      h('input', { type: 'checkbox', id: 'opt-button', checked: state.settings.showButton, onchange: onToggleButton }),
      'Show the balloon save button on problem pages'),
    h('p', { class: 'fineprint', text: 'Everything is stored in this browser only. If importing closes this popup, use Open in a tab first.' })));

  setChildren($('stats-root'), h('div', { class: 'stats' }, shelf, blocks));
}

async function onToggleButton(event) {
  state.settings = await saveSettings({ showButton: event.target.checked });
  toast(event.target.checked ? 'Save button shown on problem pages.' : 'Save button hidden.');
}

async function doExport() {
  const json = await exportData();
  const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
  const link = h('a', { href: url, download: `balloon-backup-${toKey()}.json` });
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  toast('Backup downloaded.');
}

async function doImport(file) {
  if (!file) return;
  try {
    const { added, skipped } = await importData(await file.text());
    await reload();
    renderTab(state.tab);
    toast(skipped ? `Imported ${added}, skipped ${skipped} already saved.` : `Imported ${plural(added, 'problem')}.`);
  } catch (err) {
    toast(err.message || 'Could not import that file.');
  } finally {
    $('import-file').value = '';
  }
}

const actions = {
  edit: ({ id }) => startEdit(id),
  'ask-delete': ({ id }) => { state.confirmDeleteId = id; renderLibrary(); },
  'cancel-delete': () => { state.confirmDeleteId = null; renderLibrary(); },
  'confirm-delete': async ({ id }) => {
    await deleteProblem(id);
    state.confirmDeleteId = null;
    await reload();
    if (state.editingId === id) resetFormToPage();
    renderLibrary();
    toast('Problem deleted.');
  },
  'filter-tag': ({ tag }) => {
    state.filters = { ...DEFAULT_FILTERS, tag };
    syncFilterControls();
    switchTab('library');
  },
  'clear-tag': () => { state.filters.tag = ''; renderLibrary(); },
  'clear-filters': () => { state.filters = { ...DEFAULT_FILTERS }; syncFilterControls(); renderLibrary(); },
  'tag-remove': ({ tag }) => { state.formTags = state.formTags.filter((t) => t !== tag); renderChips(); },
  'review-yes': ({ id }) => doReview(id, true),
  'review-no': ({ id }) => doReview(id, false),
  export: () => doExport(),
  import: () => $('import-file').click(),
  'open-tab': () => chrome.tabs.create({ url: chrome.runtime.getURL('index.html?view=tab') }),
  'clear-ask': () => { state.confirmClear = true; renderStats(); },
  'clear-confirm': async () => {
    await clearAll();
    state.confirmClear = false;
    await reload();
    renderStats();
    toast('All problems deleted.');
  },
};

async function doReview(id, remembered) {
  try {
    const updated = await recordReview(id, remembered);
    await reload();
    renderRevise();
    if (!remembered) toast('No problem. You will see it again tomorrow.');
    else if (updated.nextReview) toast(`Nice. Next review ${relativeLabel(updated.nextReview)}.`);
    else toast('Mastered. No more reviews for this one.');
  } catch (err) {
    console.error(err);
    toast('Could not update that review.');
  }
}

function wireEvents() {
  document.addEventListener('click', (event) => {
    const el = event.target.closest('[data-action]');
    if (!el) {
      if (state.confirmDeleteId && !event.target.closest('.confirm')) { state.confirmDeleteId = null; if (state.tab === 'library') renderLibrary(); }
      if (state.confirmClear && state.tab === 'stats') { state.confirmClear = false; renderStats(); }
      return;
    }
    const handler = actions[el.dataset.action];
    if (handler) handler({ id: el.dataset.id, tag: el.dataset.tag });
  });

  document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));

  $('theme-btn').addEventListener('click', async () => {
    state.settings = await saveSettings({ theme: resolveTheme() === 'dark' ? 'light' : 'dark' });
    applyTheme();
  });

  $('problem-form').addEventListener('submit', onSubmit);
  $('cancel-edit').addEventListener('click', () => { resetFormToPage(); switchTab('library'); });
  document.querySelectorAll('input[name="status"]').forEach((r) => r.addEventListener('change', updateStatusHint));
  $('f-title').addEventListener('input', () => { if ($('f-title').value.trim()) $('err-title').hidden = true; });
  $('f-url').addEventListener('change', () => {
    const platform = detectPlatform($('f-url').value.trim());
    if ($('f-platform').value === 'Other' && platform !== 'Other') $('f-platform').value = platform;
  });

  const tagInput = $('f-tag-input');
  tagInput.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ',') && tagInput.value.trim()) {
      e.preventDefault();
      commitPendingTag();
    } else if (e.key === 'Backspace' && !tagInput.value && state.formTags.length) {
      state.formTags.pop();
      renderChips();
    }
  });
  tagInput.addEventListener('input', (e) => {
    if (e.inputType === 'insertReplacementText' || e.inputType === undefined || tagInput.value.includes(',')) commitPendingTag();
  });
  tagInput.addEventListener('blur', commitPendingTag);
  $('tag-box').addEventListener('click', (e) => { if (!e.target.closest('button')) tagInput.focus(); });

  let searchTimer;
  $('q').addEventListener('input', (e) => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.filters.q = e.target.value; renderLibrary(); }, 120);
  });
  for (const [id, key] of [['flt-platform', 'platform'], ['flt-difficulty', 'difficulty'], ['flt-status', 'status'], ['sort', 'sort']]) {
    $(id).addEventListener('change', (e) => { state.filters[key] = e.target.value; renderLibrary(); });
  }

  $('import-file').addEventListener('change', (e) => doImport(e.target.files[0]));

  chrome.storage.onChanged.addListener(async (changes, area) => {
    if (area !== 'local' || !changes.problems) return;
    await reload();
    if (state.tab !== 'log') renderTab(state.tab);
  });
}

function buildStaticOptions() {
  $('f-platform').replaceChildren(...PLATFORMS.map((p) => h('option', { value: p, text: p })));
  $('flt-platform').replaceChildren(h('option', { value: '', text: 'Platform' }), ...PLATFORMS.map((p) => h('option', { value: p, text: p })));
}

async function init() {
  document.documentElement.dataset.theme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  if (new URLSearchParams(location.search).get('view') === 'tab') document.documentElement.classList.add('as-tab');

  buildStaticOptions();
  wireEvents();

  [state.settings, state.problems] = await Promise.all([getSettings(), getProblems()]);
  applyTheme();

  state.page = await detectPage();
  updateDueBadge();
  resetFormToPage();

  const hasDue = dueList(state.problems, toKey()).length > 0;
  switchTab(!state.page.onProblemPage && hasDue ? 'revise' : 'log');
}

init().catch((err) => {
  console.error(err);
  toast('Something went wrong while loading your data.');
});
